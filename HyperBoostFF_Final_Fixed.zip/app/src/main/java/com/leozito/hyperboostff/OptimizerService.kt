package com.leozito.hyperboostff

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader

class OptimizerService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val cmd = intent?.getStringExtra("cmd") ?: ""
        Thread {
            try {
                when {
                    cmd.startsWith("set_resolution|") -> {
                        val res = cmd.substringAfter("|")
                        applyResolution(res)
                    }
                    cmd == "apply_recommended" -> {
                        // placeholder: apply recommended (could be mocked)
                        Log.i("Optimizer", "Applying recommended settings")
                    }
                    cmd == "toggle_adb" -> {
                        // request enabling ADB over Wi-Fi (requires user action on many devices)
                        // send a notification or log for now
                        Log.i("Optimizer", "Toggle ADB requested (requires manual enable on many devices)")
                    }
                    cmd.startsWith("apply_profile|") -> {
                        val profile = cmd.substringAfter("|")
                        Log.i("Optimizer", "Applying profile: $profile")
                    }
                    cmd.startsWith("clear_cache") -> {
                        Log.i("Optimizer", "Clear cache requested")
                    }
                    else -> {
                        Log.i("Optimizer", "Unknown cmd: $cmd")
                    }
                }
            } catch (e: Exception) {
                Log.e("Optimizer", "Error: ${'$'}e")
            }
        }.start()
        return START_STICKY
    }

    private fun applyResolution(res: String) {
        try {
            val parts = res.split("x")
            if (parts.size == 2) {
                val w = parts[0].toIntOrNull() ?: return
                val h = parts[1].toIntOrNull() ?: return
                val cmds = listOf("wm size ${w}x${h}", "wm density reset")
                for (c in cmds) {
                    try {
                        val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", c))
                        process.waitFor()
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
